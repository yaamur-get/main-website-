
# دليل رفع ملفات الحوكمة

## 📁 هيكل المجلدات

```
public/governance/
├── bylaws/                    # اللوائح الأساسية
│   └── main-bylaws.pdf
├── policies/                  # السياسات
│   ├── fundraising-policy.pdf
│   ├── beneficiaries-policy.pdf
│   ├── volunteers-policy.pdf
│   ├── conflict-of-interest-policy.pdf
│   ├── whistleblowing-policy.pdf
│   ├── privacy-policy.pdf
│   └── records-policy.pdf
├── procedures/                # الآليات والإجراءات
│   ├── volunteers-procedure.pdf
│   ├── complaints-procedure.pdf
│   └── satisfaction-procedure.pdf
├── disclosure/                # الإفصاح والبيانات
│   ├── general-assembly-members.pdf
│   ├── assembly-meetings.pdf
│   ├── board-data.pdf
│   ├── contractual-relations.pdf
│   ├── family-business-relations.pdf
│   ├── permanent-committees.pdf
│   ├── ceo-info.pdf
│   └── branches-managers.pdf
└── reports/                   # التقارير والبيانات المالية
    ├── strategic-objectives.pdf
    ├── programs-reports.pdf
    ├── investment-decisions.pdf
    ├── services-statistics.pdf
    └── financial-statements.pdf
```

## 📤 كيفية رفع الملفات

### الطريقة الأولى: عبر محرر الكود في Softgen

1. **افتح محرر الكود** في واجهة Softgen
2. **انتقل إلى مجلد public** في شجرة الملفات
3. **انشئ المجلدات** إذا لم تكن موجودة:
   - governance/
   - governance/bylaws/
   - governance/policies/
   - governance/procedures/
   - governance/disclosure/
   - governance/reports/

4. **ارفع ملفات PDF** إلى المجلد المناسب:
   - اضغط على المجلد بزر الماوس الأيمن
   - اختر "Upload Files" أو "رفع ملفات"
   - اختر ملف PDF من جهازك
   - تأكد من تطابق اسم الملف مع الاسم في الكود

### الطريقة الثانية: عبر GitHub

1. **نسخ المشروع محلياً** (إذا كنت تستخدم Git):
```bash
git clone [رابط المشروع]
cd yaamur-website
```

2. **إنشاء المجلدات** إن لم تكن موجودة:
```bash
mkdir -p public/governance/{bylaws,policies,procedures,disclosure,reports}
```

3. **نسخ ملفات PDF** إلى المجلدات المناسبة

4. **رفع التغييرات**:
```bash
git add public/governance/
git commit -m "Add governance documents"
git push
```

## 🔄 كيفية استبدال ملف قديم

### عبر Softgen:

1. **احذف الملف القديم**:
   - انتقل إلى المجلد في محرر الكود
   - اضغط على الملف بزر الماوس الأيمن
   - اختر "Delete" أو "حذف"

2. **ارفع الملف الجديد**:
   - استخدم نفس الخطوات أعلاه
   - **مهم**: استخدم نفس اسم الملف القديم بالضبط

### عبر GitHub:

```bash
# استبدل الملف القديم بالجديد في نفس المكان
cp /path/to/new-file.pdf public/governance/policies/fundraising-policy.pdf

git add public/governance/policies/fundraising-policy.pdf
git commit -m "Update fundraising policy document"
git push
```

## ✏️ تعديل العناوين أو إضافة وثائق جديدة

### 1. تعديل عنوان وثيقة موجودة:

افتح ملف `src/pages/governance.tsx` وابحث عن الوثيقة المطلوبة:

```typescript
{
  id: "policy-fundraising",
  title: "سياسة جمع التبرعات",  // ← غير هذا العنوان
  description: "القواعد والإجراءات المتبعة في جمع التبرعات",  // ← أو هذا الوصف
  icon: DollarSign,
  filePath: "/governance/policies/fundraising-policy.pdf"
}
```

### 2. إضافة وثيقة جديدة:

**الخطوة 1**: أضف الوثيقة إلى القسم المناسب في `src/pages/governance.tsx`:

```typescript
{
  id: "policies",
  title: "السياسات",
  // ... الوثائق الموجودة ...
  documents: [
    // ... الوثائق الموجودة ...
    
    // إضافة وثيقة جديدة
    {
      id: "policy-new",  // معرف فريد
      title: "سياسة جديدة",  // العنوان الظاهر
      description: "وصف السياسة الجديدة",  // الوصف
      icon: Shield,  // الأيقونة
      filePath: "/governance/policies/new-policy.pdf"  // المسار
    }
  ]
}
```

**الخطوة 2**: ارفع ملف PDF للوثيقة الجديدة في المسار المحدد

### 3. إضافة قسم جديد كامل:

```typescript
const governanceSections: Section[] = [
  // ... الأقسام الموجودة ...
  
  // قسم جديد
  {
    id: "new-section",
    title: "اسم القسم الجديد",
    description: "وصف القسم الجديد",
    icon: FileText,  // أيقونة القسم
    documents: [
      {
        id: "doc1",
        title: "وثيقة 1",
        description: "وصف الوثيقة",
        icon: FileCheck,
        filePath: "/governance/new-section/doc1.pdf"
      }
    ]
  }
];
```

## 📋 قائمة الأيقونات المتاحة

يمكنك استخدام هذه الأيقونات من مكتبة Lucide React:

```typescript
import { 
  FileText,      // ملف نصي
  Shield,        // درع (حماية)
  Users,         // مجموعة مستخدمين
  UserCheck,     // مستخدم مع علامة صح
  DollarSign,    // رمز الدولار
  AlertCircle,   // تنبيه
  Lock,          // قفل
  Archive,       // أرشيف
  ClipboardList, // قائمة مهام
  MessageSquare, // رسالة
  ThumbsUp,      // إعجاب
  BarChart,      // رسم بياني
  TrendingUp,    // اتجاه صاعد
  FileBarChart,  // ملف مع رسم بياني
  Building2,     // مبنى
  FileCheck,     // ملف مع علامة صح
  Scale          // ميزان (عدالة)
} from "lucide-react";
```

## ⚠️ ملاحظات مهمة

### تنسيق أسماء الملفات:
- استخدم أحرف إنجليزية صغيرة فقط
- استبدل المسافات بشرطة `-`
- مثال صحيح: `fundraising-policy.pdf`
- مثال خاطئ: `سياسة جمع التبرعات.pdf` ❌

### حجم الملفات:
- حاول أن تكون ملفات PDF أقل من 5 ميجابايت
- استخدم ضغط PDF إذا كانت أكبر

### أمان الملفات:
- **تأكد من إخفاء** أرقام الهوية الوطنية
- **تأكد من إخفاء** المعلومات الحساسة
- راجع الملفات قبل رفعها

## 🔍 اختبار الملفات بعد الرفع

1. **احفظ التغييرات** في Softgen
2. **افتح الموقع** في المعاينة
3. **انتقل إلى صفحة الحوكمة**: `/governance`
4. **اضغط على "عرض"** لكل وثيقة للتأكد من عملها
5. **اضغط على "تحميل"** للتأكد من إمكانية التحميل

## 📞 المساعدة

إذا واجهتك مشكلة:

1. **تأكد من المسار الصحيح** للملف
2. **تأكد من تطابق اسم الملف** في الكود والمجلد
3. **تحقق من وجود الملف** في المجلد الصحيح
4. **اسأل Softgen AI** عن المشكلة المحددة

## ✅ قائمة تدقيق قبل النشر

- [ ] جميع ملفات PDF موجودة في المجلدات الصحيحة
- [ ] أسماء الملفات تطابق المسارات في الكود
- [ ] تم إخفاء المعلومات الحساسة من الملفات
- [ ] تم اختبار جميع أزرار "عرض" و "تحميل"
- [ ] العناوين والأوصاف واضحة ودقيقة
- [ ] الأيقونات مناسبة لكل وثيقة
- [ ] الموقع يعمل بشكل صحيح في المعاينة

---

**آخر تحديث:** نوفمبر 2025
**الإصدار:** 1.0
